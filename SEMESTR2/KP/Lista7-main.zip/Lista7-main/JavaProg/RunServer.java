public class RunServer {

    public static void main(String[] args) {
        Server serv = new Server();
        serv.start();
    }
    
}
