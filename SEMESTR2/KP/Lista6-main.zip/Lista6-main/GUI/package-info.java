/**
 * Pakiet zajmujacy sie interfejsem graficznym programu
 * 
 *  */ 
package GUI;
