/**
 * Pakiet zajmuje się obsługą wątków, przekazywania informacji o ich pozycjach i stanie.
 */
package GRID;
