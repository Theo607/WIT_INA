/**
 * Pakiet zawera główną klasę, która obsługuje uruchamianie całego programu.
 * @author Mateusz Smuga
 * @version 1.0
 */
package App;